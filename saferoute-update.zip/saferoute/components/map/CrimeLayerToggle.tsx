"use client";

import { CircleAlert, Eye, EyeOff } from "lucide-react";
import { Spinner } from "@/components/ui/Spinner";
import type { IncidentLayerState } from "@/lib/useIncidents";

interface CrimeLayerToggleProps {
  layer: IncidentLayerState;
  visible: boolean;
  onToggle: () => void;
  onRetry: () => void;
}

/** Map chip that shows/hides reported crimes and says how many are in view. */
export function CrimeLayerToggle({ layer, visible, onToggle, onRetry }: CrimeLayerToggleProps) {
  let detail: React.ReactNode;
  if (layer.status === "loading") detail = <Spinner className="size-3.5 text-ink-muted" />;
  else if (layer.status === "zoomed-out") detail = <span className="text-ink-muted">Zoom in</span>;
  else if (layer.status === "error") detail = <CircleAlert className="size-3.5 text-danger" aria-hidden="true" />;
  else if (layer.status === "ready" && !layer.dataAvailable) detail = <span className="text-ink-muted">None collected yet</span>;
  else if (layer.status === "ready") detail = <span className="tabular-nums">{layer.incidents.length} in view</span>;

  const title =
    layer.status === "error"
      ? `${layer.error} Click to retry.`
      : [layer.sourceNote, layer.windowDays ? `Last ${layer.windowDays} days.` : null].filter(Boolean).join(" ");

  return (
    <button
      type="button"
      onClick={layer.status === "error" ? onRetry : onToggle}
      aria-pressed={visible}
      title={title || "Reported crimes"}
      className={`pointer-events-auto inline-flex h-10 items-center gap-2 rounded-2xl border border-line bg-paper/95 px-3 text-sm font-medium shadow-float backdrop-blur transition-opacity ${
        visible ? "text-ink" : "text-ink-muted"
      }`}
    >
      <span className={`size-2.5 rounded-full ${visible ? "bg-[#DC2626]" : "bg-line-strong"}`} aria-hidden="true" />
      <span className="hidden sm:inline">Reported crimes</span>
      <span className="sm:hidden">Crimes</span>
      {detail && <span className="text-xs font-normal">{detail}</span>}
      {visible ? (
        <Eye className="size-4 text-ink-muted" aria-hidden="true" />
      ) : (
        <EyeOff className="size-4 text-ink-muted" aria-hidden="true" />
      )}
    </button>
  );
}
