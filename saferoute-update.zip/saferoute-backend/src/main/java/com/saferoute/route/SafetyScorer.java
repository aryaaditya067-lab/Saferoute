package com.saferoute.route;

import com.saferoute.config.SafeRouteProperties;
import com.saferoute.geo.BBox;
import com.saferoute.geo.Geo;
import com.saferoute.geo.LatLng;
import com.saferoute.incident.CrimeType;
import com.saferoute.incident.Incident;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Measures each candidate route and picks Fastest / Balanced / Safest.
 *
 * <p>Pure computation: no I/O, so it is fully unit-tested. Factors that have no
 * data are reported as unavailable and left out of the ranking rather than
 * treated as zero.
 */
public class SafetyScorer {

    public enum Label { FASTEST, BALANCED, SAFEST }

    public enum Factor { CRIME, DARKNESS, POLICE, HOSPITAL }

    public record Scored(RouteCandidate route, RouteSafety safety, Set<Label> labels) {}

    public record Outcome(List<Scored> routes, List<Factor> factorsUsed) {}

    static final double SAMPLE_STEP_METERS = 25;
    static final double LIT_MATCH_METERS = 15;
    /** Lighting is ranked only if at least this share of every route has a known lit tag. */
    static final double MIN_LIGHTING_KNOWN = 0.2;

    private final SafeRouteProperties.Safety config;

    public SafetyScorer(SafeRouteProperties.Safety config) {
        this.config = config;
    }

    /**
     * @param incidents        reports inside the window (null = crime data unavailable)
     * @param osm              OpenStreetMap context (null = unavailable)
     */
    public Outcome score(List<RouteCandidate> candidates, List<Incident> incidents, OsmContext osm, LocalDate today) {
        List<RouteSafety> measured = new ArrayList<>();
        for (RouteCandidate route : candidates) {
            List<LatLng> samples = Geo.resample(route.geometry(), SAMPLE_STEP_METERS);
            measured.add(new RouteSafety(
                    incidents == null ? RouteSafety.Crime.unavailable() : crime(route.geometry(), incidents, today),
                    osm == null ? RouteSafety.Lighting.unavailable() : lighting(samples, osm.litWays()),
                    osm == null ? RouteSafety.Service.unavailable() : service(samples, osm.police()),
                    osm == null ? RouteSafety.Service.unavailable() : service(samples, osm.hospitals()),
                    null));
        }

        List<Factor> used = new ArrayList<>();
        if (incidents != null) used.add(Factor.CRIME);
        if (osm != null && measured.stream().allMatch(s -> 1 - s.lighting().unknownFraction() >= MIN_LIGHTING_KNOWN)) {
            used.add(Factor.DARKNESS);
        }
        if (osm != null && !osm.police().isEmpty()) used.add(Factor.POLICE);
        if (osm != null && !osm.hospitals().isEmpty()) used.add(Factor.HOSPITAL);

        double maxExposure = measured.stream().mapToDouble(s -> s.crime().exposure()).max().orElse(0);
        SafeRouteProperties.Weights w = config.weights();
        List<RouteSafety> withRisk = new ArrayList<>();
        for (RouteSafety s : measured) {
            if (used.isEmpty()) {
                withRisk.add(s);
                continue;
            }
            double sum = 0, weights = 0;
            if (used.contains(Factor.CRIME)) {
                sum += w.crime() * (maxExposure > 0 ? s.crime().exposure() / maxExposure : 0);
                weights += w.crime();
            }
            if (used.contains(Factor.DARKNESS)) {
                sum += w.darkness() * s.lighting().unlitFraction();
                weights += w.darkness();
            }
            if (used.contains(Factor.POLICE)) {
                sum += w.police() * (1 - s.police().coverageFraction());
                weights += w.police();
            }
            if (used.contains(Factor.HOSPITAL)) {
                sum += w.hospital() * (1 - s.hospital().coverageFraction());
                weights += w.hospital();
            }
            withRisk.add(s.withRisk(weights > 0 ? round(sum / weights, 4) : null));
        }

        Map<Integer, Set<Label>> labels = label(candidates, withRisk);
        List<Scored> out = new ArrayList<>();
        for (int i = 0; i < candidates.size(); i++) {
            out.add(new Scored(candidates.get(i), withRisk.get(i), labels.getOrDefault(i, EnumSet.noneOf(Label.class))));
        }
        return new Outcome(out, used);
    }

    static Map<Integer, Set<Label>> label(List<RouteCandidate> routes, List<RouteSafety> safety) {
        Map<Integer, Set<Label>> labels = new LinkedHashMap<>();
        if (routes.isEmpty()) return labels;
        int fastest = argMin(routes.size(), i -> routes.get(i).durationSeconds(), i -> routes.get(i).distanceMeters());
        labels.computeIfAbsent(fastest, k -> EnumSet.noneOf(Label.class)).add(Label.FASTEST);
        boolean ranked = safety.stream().allMatch(s -> s.riskIndex() != null);
        if (!ranked) return labels;

        int safest = argMin(routes.size(), i -> safety.get(i).riskIndex(), i -> routes.get(i).durationSeconds());
        labels.computeIfAbsent(safest, k -> EnumSet.noneOf(Label.class)).add(Label.SAFEST);

        double minD = routes.stream().mapToDouble(RouteCandidate::durationSeconds).min().orElse(0);
        double maxD = routes.stream().mapToDouble(RouteCandidate::durationSeconds).max().orElse(0);
        double minR = safety.stream().mapToDouble(RouteSafety::riskIndex).min().orElse(0);
        double maxR = safety.stream().mapToDouble(RouteSafety::riskIndex).max().orElse(0);
        int balanced = argMin(routes.size(),
                i -> 0.5 * norm(routes.get(i).durationSeconds(), minD, maxD) + 0.5 * norm(safety.get(i).riskIndex(), minR, maxR),
                i -> routes.get(i).durationSeconds());
        labels.computeIfAbsent(balanced, k -> EnumSet.noneOf(Label.class)).add(Label.BALANCED);
        return labels;
    }

    RouteSafety.Crime crime(List<LatLng> geometry, List<Incident> incidents, LocalDate today) {
        BBox near = BBox.around(geometry).expand(config.maxIncidentRadiusMeters());
        double exposure = 0;
        int violent = 0, property = 0;
        List<Long> ids = new ArrayList<>();
        for (Incident incident : incidents) {
            if (!near.contains(incident.center())) continue;
            int radius = Math.max(config.minIncidentRadiusMeters(), Math.min(config.maxIncidentRadiusMeters(), incident.radiusMeters()));
            if (Geo.distanceToPolylineMeters(incident.center(), geometry) > radius) continue;
            long ageDays = Math.max(0, ChronoUnit.DAYS.between(incident.occurredOn(), today));
            double recency = Math.pow(0.5, ageDays / Math.max(1, config.recencyHalfLifeDays()));
            boolean isViolent = incident.type().category == CrimeType.Category.VIOLENT;
            double categoryWeight = isViolent ? config.categoryWeights().violent() : config.categoryWeights().property();
            exposure += categoryWeight * recency;
            if (isViolent) violent++; else property++;
            ids.add(incident.id());
        }
        return new RouteSafety.Crime(true, ids.size(), violent, property, round(exposure, 4), ids);
    }

    static RouteSafety.Lighting lighting(List<LatLng> samples, List<OsmContext.LitWay> ways) {
        if (samples.isEmpty()) return RouteSafety.Lighting.unavailable();
        int lit = 0, unlit = 0;
        for (LatLng p : samples) {
            double best = LIT_MATCH_METERS;
            Boolean value = null;
            for (OsmContext.LitWay way : ways) {
                if (!way.bounds().expand(LIT_MATCH_METERS).contains(p)) continue;
                double d = Geo.distanceToPolylineMeters(p, way.geometry());
                if (d <= best) {
                    best = d;
                    value = way.lit();
                }
            }
            if (value == null) continue;
            if (value) lit++; else unlit++;
        }
        double n = samples.size();
        return new RouteSafety.Lighting(true, round(lit / n, 3), round(unlit / n, 3), round((n - lit - unlit) / n, 3));
    }

    RouteSafety.Service service(List<LatLng> samples, List<OsmContext.Poi> pois) {
        if (samples.isEmpty()) return RouteSafety.Service.unavailable();
        double radius = config.serviceRadiusMeters();
        int covered = 0;
        Set<Long> nearby = new HashSet<>();
        for (LatLng p : samples) {
            boolean hit = false;
            for (OsmContext.Poi poi : pois) {
                if (Geo.distanceMeters(p, poi.location()) <= radius) {
                    hit = true;
                    nearby.add(poi.osmId());
                }
            }
            if (hit) covered++;
        }
        return new RouteSafety.Service(true, round(covered / (double) samples.size(), 3), nearby.size());
    }

    private interface IndexValue {
        double at(int index);
    }

    private static int argMin(int size, IndexValue primary, IndexValue tieBreak) {
        Integer best = null;
        for (int i = 0; i < size; i++) {
            if (best == null) {
                best = i;
                continue;
            }
            double a = primary.at(i), b = primary.at(best);
            if (a < b - 1e-9 || (Math.abs(a - b) <= 1e-9 && tieBreak.at(i) < tieBreak.at(best))) best = i;
        }
        return best == null ? 0 : best;
    }

    private static double norm(double value, double min, double max) {
        return max - min < 1e-9 ? 0 : (value - min) / (max - min);
    }

    static double round(double value, int places) {
        double f = Math.pow(10, places);
        return Math.round(value * f) / f;
    }

    /** Most heavily weighted incident area on a route, used to look for a detour around it. */
    static Incident worstIncident(List<LatLng> geometry, List<Incident> incidents, SafeRouteProperties.Safety config, LocalDate today) {
        return incidents.stream()
                .filter(i -> Geo.distanceToPolylineMeters(i.center(), geometry)
                        <= Math.max(config.minIncidentRadiusMeters(), Math.min(config.maxIncidentRadiusMeters(), i.radiusMeters())))
                .max(Comparator.comparingDouble(i -> {
                    double w = i.type().category == CrimeType.Category.VIOLENT ? config.categoryWeights().violent() : config.categoryWeights().property();
                    long age = Math.max(0, ChronoUnit.DAYS.between(i.occurredOn(), today));
                    return w * Math.pow(0.5, age / Math.max(1, config.recencyHalfLifeDays()));
                }))
                .orElse(null);
    }
}
