package com.saferoute.route;

import java.util.List;

/** Measured safety facts for one route. Every number is computed from stored or fetched data. */
public record RouteSafety(Crime crime, Lighting lighting, Service police, Service hospital, Double riskIndex) {

    /** Reported incidents whose area the route passes through. */
    public record Crime(boolean available, int incidentCount, int violentCount, int propertyCount,
                        double exposure, List<Long> incidentIds) {
        public static Crime unavailable() {
            return new Crime(false, 0, 0, 0, 0, List.of());
        }
    }

    /** Share of the route length on roads tagged lit / unlit / not tagged in OpenStreetMap. */
    public record Lighting(boolean available, double litFraction, double unlitFraction, double unknownFraction) {
        public static Lighting unavailable() {
            return new Lighting(false, 0, 0, 1);
        }
    }

    /** Share of the route within the service radius of a police station / hospital. */
    public record Service(boolean available, double coverageFraction, int nearbyCount) {
        public static Service unavailable() {
            return new Service(false, 0, 0);
        }
    }

    public RouteSafety withRisk(Double risk) {
        return new RouteSafety(crime, lighting, police, hospital, risk);
    }
}
