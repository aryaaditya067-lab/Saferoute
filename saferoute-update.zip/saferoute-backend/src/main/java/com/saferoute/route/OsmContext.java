package com.saferoute.route;

import com.saferoute.geo.BBox;
import com.saferoute.geo.LatLng;
import java.util.List;

/** OpenStreetMap features around a set of routes. */
public record OsmContext(List<LitWay> litWays, List<Poi> police, List<Poi> hospitals) {

    /** A road whose {@code lit} tag is known. */
    public record LitWay(List<LatLng> geometry, boolean lit, BBox bounds) {}

    public record Poi(long osmId, String name, LatLng location) {}
}
