package com.saferoute.route;

import com.fasterxml.jackson.databind.JsonNode;
import com.saferoute.common.ApiException;
import com.saferoute.common.HttpFetcher;
import com.saferoute.common.Json;
import com.saferoute.common.RequestGate;
import com.saferoute.common.TtlCache;
import com.saferoute.config.SafeRouteProperties;
import com.saferoute.geo.BBox;
import com.saferoute.geo.LatLng;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Component;

/** Street lighting, police stations and hospitals from OpenStreetMap via the Overpass API. */
@Component
public class OverpassClient {

    private static final Set<String> LIT = Set.of("yes", "24/7", "automatic", "sunset-sunrise", "interval", "limited");
    private static final Set<String> UNLIT = Set.of("no", "disused");

    private final HttpFetcher http;
    private final String url;
    private final RequestGate gate = new RequestGate(2_000);
    private final TtlCache<OsmContext> cache = new TtlCache<>(50, Duration.ofHours(6));

    public OverpassClient(HttpFetcher http, SafeRouteProperties properties) {
        this.http = http;
        this.url = properties.providers().overpassUrl();
    }

    public OsmContext fetch(BBox box) {
        String key = String.format(Locale.ROOT, "%.3f,%.3f,%.3f,%.3f", box.south(), box.west(), box.north(), box.east());
        OsmContext cached = cache.get(key);
        if (cached != null) return cached;

        String b = String.format(Locale.ROOT, "%.5f,%.5f,%.5f,%.5f", box.south(), box.west(), box.north(), box.east());
        String query = "[out:json][timeout:25];"
                + "way[\"highway\"][\"lit\"](" + b + ")->.lit;"
                + "(node[\"amenity\"=\"police\"](" + b + ");way[\"amenity\"=\"police\"](" + b + ");"
                + "node[\"amenity\"=\"hospital\"](" + b + ");way[\"amenity\"=\"hospital\"](" + b + ");"
                + "node[\"healthcare\"=\"hospital\"](" + b + ");way[\"healthcare\"=\"hospital\"](" + b + ");)->.poi;"
                + ".lit out geom;.poi out center;";
        gate.acquire();
        HttpFetcher.Response response = http.get(url + "?data=" + URLEncoder.encode(query, StandardCharsets.UTF_8),
                Map.of("Accept", "application/json"), Duration.ofSeconds(35), 32 * 1024 * 1024);
        if (!response.ok()) {
            throw new ApiException(ApiException.Code.UPSTREAM_UNAVAILABLE, "OpenStreetMap data service returned HTTP " + response.status() + ".");
        }
        OsmContext context = parse(response.body());
        cache.put(key, context);
        return context;
    }

    /** Package-private for tests. */
    static OsmContext parse(String body) {
        JsonNode root = Json.parse(body, "the OpenStreetMap data service");
        List<OsmContext.LitWay> ways = new ArrayList<>();
        List<OsmContext.Poi> police = new ArrayList<>();
        List<OsmContext.Poi> hospitals = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (JsonNode element : root.path("elements")) {
            String type = element.path("type").asText("");
            long id = element.path("id").asLong();
            JsonNode tags = element.path("tags");
            String litValue = tags.path("lit").asText("").toLowerCase(Locale.ROOT);
            boolean isRoad = tags.has("highway");
            if (isRoad && "way".equals(type) && element.has("geometry") && (LIT.contains(litValue) || UNLIT.contains(litValue))) {
                List<LatLng> geometry = new ArrayList<>();
                for (JsonNode p : element.path("geometry")) {
                    geometry.add(new LatLng(p.path("lat").asDouble(), p.path("lon").asDouble()));
                }
                if (geometry.size() >= 2) {
                    ways.add(new OsmContext.LitWay(geometry, LIT.contains(litValue), BBox.around(geometry)));
                }
                continue;
            }
            boolean isPolice = "police".equals(tags.path("amenity").asText(""));
            boolean isHospital = "hospital".equals(tags.path("amenity").asText("")) || "hospital".equals(tags.path("healthcare").asText(""));
            if (!isPolice && !isHospital) continue;
            if (!seen.add(type + id)) continue;
            JsonNode point = "node".equals(type) ? element : element.path("center");
            if (!point.has("lat") || !point.has("lon")) continue;
            OsmContext.Poi poi = new OsmContext.Poi(id, tags.path("name").asText(""),
                    new LatLng(point.path("lat").asDouble(), point.path("lon").asDouble()));
            if (isPolice) police.add(poi);
            if (isHospital) hospitals.add(poi);
        }
        return new OsmContext(ways, police, hospitals);
    }
}
