package com.saferoute.ingest;

import com.saferoute.common.ApiException;
import com.saferoute.common.HttpFetcher;
import com.saferoute.config.SafeRouteProperties;
import com.saferoute.incident.CrimeType;
import com.saferoute.incident.Incident;
import com.saferoute.incident.IncidentStore;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Collects recent street-crime reports for the configured city:
 * MiMo web search → each claim verified against its article → locality
 * geocoded inside the city → de-duplicated → stored.
 */
@Service
public class IncidentIngestService {

    private static final Logger log = LoggerFactory.getLogger(IncidentIngestService.class);

    public record Report(
            boolean ran,
            String message,
            int candidates,
            int accepted,
            int merged,
            int alreadyKnown,
            Map<String, Integer> rejected) {}

    private final MimoClient mimo;
    private final ArticleVerifier verifier;
    private final LocalityGeocoder geocoder;
    private final IncidentStore store;
    private final SafeRouteProperties properties;
    private final Clock clock;

    public IncidentIngestService(
            MimoClient mimo,
            HttpFetcher http,
            LocalityGeocoder geocoder,
            IncidentStore store,
            SafeRouteProperties properties,
            Clock clock) {
        this.mimo = mimo;
        this.verifier = new ArticleVerifier(http, properties.city().aliases());
        this.geocoder = geocoder;
        this.store = store;
        this.properties = properties;
        this.clock = clock;
    }

    @Scheduled(fixedDelayString = "${saferoute.ingest.interval}", initialDelayString = "${saferoute.ingest.initial-delay}")
    public void scheduledRun() {
        if (!properties.ingest().enabled()) return;
        if (!mimo.configured()) {
            log.info("Crime ingest skipped: MIMO_API_KEY is not set.");
            return;
        }
        Report report = runOnce();
        log.info("Crime ingest: {}", report);
    }

    public synchronized Report runOnce() {
        if (!mimo.configured()) {
            return new Report(false, "MIMO_API_KEY is not set.", 0, 0, 0, 0, Map.of());
        }
        Instant started = clock.instant();
        long runId = store.startRun(started);
        LocalDate today = LocalDate.now(clock);
        int lookback = properties.ingest().lookbackDays();
        Map<ArticleVerifier.Rejection, Integer> rejected = new EnumMap<>(ArticleVerifier.Rejection.class);
        int candidatesCount = 0, accepted = 0, merged = 0, known = 0, notLocated = 0;

        try {
            MimoClient.SearchAnswer answer = mimo.searchAndAnswer(systemPrompt(), userPrompt(today, lookback));
            List<NewsCandidate> candidates = CandidateParser.parse(answer.content());
            candidatesCount = candidates.size();
            int processed = 0;
            for (NewsCandidate candidate : candidates) {
                if (processed++ >= properties.ingest().maxArticlesPerRun()) break;
                if (store.sourceExists(candidate.url())) {
                    known++;
                    continue;
                }
                ArticleVerifier.Result result = verifier.verify(candidate, answer.citations(), today, lookback);
                if (!result.accepted()) {
                    rejected.merge(result.rejection(), 1, Integer::sum);
                    continue;
                }
                ArticleVerifier.Verified v = result.verified();
                if (store.sourceExists(v.url())) {
                    known++;
                    continue;
                }
                Optional<LocalityGeocoder.Place> place;
                try {
                    place = geocoder.locate(candidate.locality());
                } catch (ApiException e) {
                    place = Optional.empty();
                }
                if (place.isEmpty()) {
                    notLocated++;
                    continue;
                }
                Incident.Source source = new Incident.Source(v.url(), v.title(), v.site(), v.publishedOn());
                String localityKey = localityKey(candidate.locality());
                Optional<Long> duplicate = store.findDuplicate(v.type(), localityKey, v.occurredOn());
                if (duplicate.isPresent()) {
                    store.addSource(duplicate.get(), source, clock.instant());
                    merged++;
                } else {
                    store.insert(new IncidentStore.NewIncident(
                            v.type(), headline(candidate, v), candidate.locality().trim(), localityKey,
                            place.get().label(), place.get().center(), place.get().radiusMeters(),
                            v.occurredOn(), candidate.evidenceQuote().trim()), source, clock.instant());
                    accepted++;
                }
            }
            int rejectedTotal = rejected.values().stream().mapToInt(Integer::intValue).sum() + notLocated;
            store.finishRun(runId, clock.instant(), true,
                    new IncidentStore.RunStats(candidatesCount, accepted, merged, rejectedTotal), null);
        } catch (RuntimeException e) {
            int rejectedTotal = rejected.values().stream().mapToInt(Integer::intValue).sum() + notLocated;
            store.finishRun(runId, clock.instant(), false,
                    new IncidentStore.RunStats(candidatesCount, accepted, merged, rejectedTotal), e.getMessage());
            log.warn("Crime ingest failed: {}", e.getMessage());
            return new Report(true, "Failed: " + e.getMessage(), candidatesCount, accepted, merged, known, toMap(rejected, notLocated));
        }
        return new Report(true, "OK", candidatesCount, accepted, merged, known, toMap(rejected, notLocated));
    }

    private static Map<String, Integer> toMap(Map<ArticleVerifier.Rejection, Integer> rejected, int notLocated) {
        Map<String, Integer> out = new java.util.LinkedHashMap<>();
        rejected.forEach((k, v) -> out.put(k.name().toLowerCase(), v));
        if (notLocated > 0) out.put("locality_not_found", notLocated);
        return out;
    }

    static String localityKey(String locality) {
        return ArticleVerifier.stripPunctuation(HtmlText.normalize(locality));
    }

    private static String headline(NewsCandidate c, ArticleVerifier.Verified v) {
        if (!c.headline().isBlank()) return c.headline().trim();
        return v.title();
    }

    String systemPrompt() {
        return "You are a careful news researcher. You only report what news articles you found actually say. "
                + "You never invent articles, URLs, places, dates or quotes. You answer with a JSON array only, no prose.";
    }

    String userPrompt(LocalDate today, int lookbackDays) {
        SafeRouteProperties.City city = properties.city();
        int max = properties.ingest().maxArticlesPerRun();
        return "Today is " + today + ". Search the web for news articles published in the last " + lookbackDays
                + " days about crimes that happened in " + city.name() + ", " + city.region() + ", " + city.country() + ".\n"
                + "Only include these crime types (use these ids): " + CrimeType.allowedIds() + ".\n"
                + "Ignore cyber crime, fraud, scams, political news, court verdicts about old cases and anything outside " + city.name() + ".\n"
                + "Return a JSON array with at most " + max + " objects, one per article, with exactly these fields:\n"
                + "- url: the exact article URL as it appears in your search results\n"
                + "- headline: the article headline\n"
                + "- published_date: YYYY-MM-DD\n"
                + "- crime_type: one id from the list above\n"
                + "- locality: the specific neighbourhood, area or road in " + city.name()
                + " where the crime happened, as written in the article (not just the city name)\n"
                + "- incident_date: YYYY-MM-DD if the article states it, otherwise an empty string\n"
                + "- evidence_quote: one sentence copied word for word from the article that mentions the crime and the locality\n"
                + "Only include articles that appear in your search results. If you found none, return [].";
    }
}
