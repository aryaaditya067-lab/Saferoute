# SafeRoute backend (Java Spring Boot)

This is the server behind SafeRoute's safety features. It does three things:

1. **Collects reported crimes.** It uses MiMo web search to find recent crime news and checks each report against its article. Reports that pass are stored with an approximate location.
2. **Ranks routes.** It builds candidate routes, measures each one, and labels them **Fastest**, **Balanced** and **Safest**.
3. **Proxies search and routing** for the Next.js app (`../saferoute`). That way the browser only talks to this server.

## Run it (Windows PowerShell)

You need **Java 21**. Android Studio ships one (its `jbr` folder), and Gradle downloads one automatically if it's missing.

```powershell
cd saferoute-backend
$env:MIMO_API_KEY = "<your MiMo key>"                 # never commit this
$env:SAFEROUTE_ADMIN_TOKEN = "<any long random text>"  # protects the manual ingest endpoint
$env:SAFEROUTE_CONTACT_EMAIL = "<your email>"          # sent in the User-Agent to public OSM services
.\gradlew.bat bootRun
```

The server runs at http://localhost:8080.

- **Status:** http://localhost:8080/api/v1/status
- **Collecting reports:** the first run starts 30 seconds after the server starts, then repeats every 3 hours. To run one now:
  ```powershell
  Invoke-RestMethod -Method Post http://localhost:8080/api/v1/admin/ingest -Headers @{ "X-Admin-Token" = $env:SAFEROUTE_ADMIN_TOKEN }
  ```
  The response shows how many reports were accepted, merged and rejected, and why each rejected one failed.
- **Turning it on in the frontend:** in `../saferoute`, create `.env.local` containing `NEXT_PUBLIC_API_BASE_URL=http://localhost:8080`, then restart `npm run dev`.

Data is stored in `./data/` as an H2 database file. There is nothing to install. Delete the folder to start fresh.

**MiMo setup:** enable the Web Search plugin in the MiMo console (Plugin Management). Each ingest run makes one web-search request, and MiMo bills web search per request on top of tokens.

## How crime reports are collected

Every step can reject a report. Only reports that pass every step are stored.

| Step | What is checked |
|---|---|
| MiMo web search | Asked for crime news in the city from the last 3 days, as JSON, limited to the street-crime types in `CrimeType` (robbery, chain snatching, assault…). Cyber crime and fraud are excluded. |
| URL | Must be one of the pages the search actually returned (`message.annotations`). URLs the model made up are rejected. |
| Article | The backend downloads the page itself. The quoted sentence, the locality and the city name must all appear in the article text. |
| Date | The incident or publish date must fall inside the lookback window. Old stories that resurface are rejected. |
| Location | The locality is geocoded with Photon, restricted to the city's bounding box. The radius comes from the place's real extent (250–1500 m), because news gives an area, not an address. |
| Duplicates | The same crime type in the same locality within ±1 day becomes one incident with several sources. |

The map shows these reports as **news reports, not official police records**.

## How routes are ranked

1. **Candidates.** OSRM returns up to 3 alternatives. If the fastest route crosses a reported-crime area, the backend also asks for 2 detours that pass on either side of it. Any route more than 1.5× slower than the fastest is dropped, and near-duplicates are merged.
2. **Measurements per route** (all computed, nothing estimated):
   - **Crime:** reported incidents whose area the route passes through, within the last 90 days. Violent crimes count 1.0 and property crimes 0.5. A report counts half as much after 30 days.
   - **Darkness:** the share of the route on roads OpenStreetMap tags `lit=no`, out of all roads tagged `lit`.
   - **Police / hospital:** the share of the route within 1 km of a police station or hospital in OpenStreetMap.
3. **Missing data is left out, never counted as zero.** If no reports have been collected yet, or the trip is outside the city, the crime factor is skipped. If any candidate has less than 20% of its length tagged `lit`, lighting is skipped for all candidates. If nothing is measurable, only "Fastest" is labelled.
4. **Labels:**
   - **Fastest:** shortest travel time.
   - **Safest:** lowest weighted combination of the measured factors.
   - **Balanced:** best 50/50 mix of normalised time and safety.

   One route can carry more than one label.

Weights and thresholds are in `application.yml` under `saferoute.safety`, and you can tune them. The API returns the factors and weights it used, and the app shows them under "How is 'Safest' chosen?".

## API

| Method | Path | Returns |
|---|---|---|
| POST | `/api/v1/routes` | `RouteResponse` (routes with `labels` + `safety` facts, and the method used) |
| GET | `/api/v1/incidents?south=&west=&north=&east=` | `IncidentsResponse` |
| GET | `/api/v1/geocode/search?q=&limit=&lat=&lng=` | `Location[]` |
| GET | `/api/v1/geocode/reverse?lat=&lng=` | `{ "place": Location \| null }` |
| GET | `/api/v1/status` | Pipeline health |
| POST | `/api/v1/admin/ingest` | Runs one ingest. Needs the `X-Admin-Token` header |

The frontend's `types/index.ts` mirrors these shapes.

## Configuration (environment variables)

| Variable | Default |
|---|---|
| `MIMO_API_KEY` | none (no ingest without it) |
| `MIMO_MODEL` | `mimo-v2.6-flash` |
| `SAFEROUTE_ADMIN_TOKEN` | none (manual ingest disabled) |
| `SAFEROUTE_INGEST_INTERVAL` | `PT3H` |
| `SAFEROUTE_ALLOWED_ORIGINS` | `http://localhost:3000` |
| `SAFEROUTE_ROUTER_URL` / `SAFEROUTE_GEOCODER_URL` / `SAFEROUTE_OVERPASS_URL` | the public FOSSGIS OSRM / Photon / Overpass servers |
| `PORT` | `8080` |

The city, its bounding box and all safety weights are set in `src/main/resources/application.yml`.

## Tests

```powershell
.\gradlew.bat test
```

The tests cover geometry, the full ingest pipeline (search → verify → geocode → merge), the article checks, parsing of OSRM and Overpass responses, and route labelling, including the cases where data is missing. They use synthetic fixtures in the providers' response formats, so no network is needed.

## Limits to know

- News covers only the crimes that get reported in the press, and locations are approximate (area level).
- OpenStreetMap lighting tags are sparse in many Indian cities, so lighting is often reported as "not mapped".
- Photon, OSRM (FOSSGIS) and Overpass are public, fair-use services, and this backend rate-limits its calls to them. For real traffic, self-host them or use paid providers.
- Travel times don't include live traffic.
