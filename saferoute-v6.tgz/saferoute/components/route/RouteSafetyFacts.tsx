import { Building2, CircleCheck, Lightbulb, MessageCircleWarning, MessageSquareWarning, Route as RouteIcon, Siren, Store } from "lucide-react";
import type { ReactNode } from "react";
import type { RouteSafety } from "@/types";

const pct = (fraction: number) => `${Math.round(fraction * 100)}%`;
const formatMeters = (m: number) => (m < 1000 ? `${Math.round(m / 10) * 10} m` : `${(m / 1000).toFixed(1)} km`);

function Fact({ icon, children, tone = "neutral" }: { icon: ReactNode; children: ReactNode; tone?: "neutral" | "warn" | "good" }) {
  return (
    <li className="flex items-start gap-2">
      <span className={`mt-px ${tone === "warn" ? "text-danger" : tone === "good" ? "text-safe" : "text-ink-muted"}`}>{icon}</span>
      <span className="text-ink-soft">{children}</span>
    </li>
  );
}

/** Measured facts about a route. Factors without data say so instead of guessing. */
export function RouteSafetyFacts({ safety, serviceRadiusMeters }: { safety: RouteSafety; serviceRadiusMeters: number }) {
  const { crime, community, lighting, roads, activity, police, hospital } = safety;
  const radius = serviceRadiusMeters >= 1000 ? `${serviceRadiusMeters / 1000} km` : `${serviceRadiusMeters} m`;
  const iconClass = "size-3.5";

  return (
    <ul className="mt-2 flex flex-col gap-1.5 text-xs">
      {crime.available ? (
        crime.incidentCount === 0 ? (
          <Fact tone="good" icon={<CircleCheck className={iconClass} aria-hidden="true" />}>
            No reported crime areas on this route
          </Fact>
        ) : (
          <Fact tone="warn" icon={<MessageCircleWarning className={iconClass} aria-hidden="true" />}>
            Passes {crime.incidentCount} reported crime area{crime.incidentCount === 1 ? "" : "s"}
            {crime.violentCount > 0 && ` (${crime.violentCount} violent)`}
            {crime.nearestMeters != null &&
              (crime.nearestMeters < 20 ? " · one is right on the route" : ` · closest ${formatMeters(crime.nearestMeters)} away`)}
          </Fact>
        )
      ) : (
        <Fact icon={<MessageCircleWarning className={iconClass} aria-hidden="true" />}>Crime reports not available here</Fact>
      )}

      {community?.available &&
        (community.spotCount === 0 ? (
          <Fact tone="good" icon={<CircleCheck className={iconClass} aria-hidden="true" />}>
            No community-flagged spots on this route
          </Fact>
        ) : (
          <Fact tone="warn" icon={<MessageSquareWarning className={iconClass} aria-hidden="true" />}>
            {community.spotCount} community-flagged spot{community.spotCount === 1 ? "" : "s"} ({community.categories.join(", ")})
          </Fact>
        ))}

      {lighting.available &&
        (lighting.unknownFraction >= 0.8 ? (
          <Fact icon={<Lightbulb className={iconClass} aria-hidden="true" />}>Street lighting mostly not mapped</Fact>
        ) : (
          <Fact
            tone={lighting.unlitFraction > 0.3 ? "warn" : "neutral"}
            icon={<Lightbulb className={iconClass} aria-hidden="true" />}
          >
            {pct(lighting.litFraction)} lit · {pct(lighting.unlitFraction)} unlit · {pct(lighting.unknownFraction)} not mapped
          </Fact>
        ))}

      {roads?.available && roads.mainRoadFraction + roads.minorRoadFraction >= 0.5 && (
        <Fact icon={<RouteIcon className={iconClass} aria-hidden="true" />}>
          {pct(roads.mainRoadFraction)} on main roads · {pct(roads.minorRoadFraction)} on smaller streets
        </Fact>
      )}

      {activity?.available && (
        <Fact icon={<Store className={iconClass} aria-hidden="true" />}>
          {activity.placeCount === 0
            ? "No shops or eateries mapped along the way"
            : `${activity.placeCount} shops, eateries & ATMs along the way (${activity.placesPerKm.toFixed(1)}/km)`}
        </Fact>
      )}

      {police.available && (
        <Fact icon={<Siren className={iconClass} aria-hidden="true" />}>
          {pct(police.coverageFraction)} within {radius} of a police station
        </Fact>
      )}
      {hospital.available && (
        <Fact icon={<Building2 className={iconClass} aria-hidden="true" />}>
          {pct(hospital.coverageFraction)} within {radius} of a hospital
        </Fact>
      )}
    </ul>
  );
}
