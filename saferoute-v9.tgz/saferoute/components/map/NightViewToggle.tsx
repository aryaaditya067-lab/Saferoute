"use client";

import { CircleAlert, Moon } from "lucide-react";
import { Spinner } from "@/components/ui/Spinner";
import type { NightLightsLayer } from "@/lib/useNightLights";
import { nightLightsYear } from "@/services/nightLights";

/** "Night view" chip: shows how bright each part of the city is at night (NASA satellite). */
export function NightViewToggle({ layer }: { layer: NightLightsLayer }) {
  const year = nightLightsYear(layer.data?.source ?? null);
  const problem = layer.status === "unavailable" || layer.status === "error";
  return (
    <>
      <button
        type="button"
        onClick={layer.toggle}
        aria-pressed={layer.visible}
        title={layer.message ?? "See how bright the city is at night (NASA satellite)"}
        className={`pointer-events-auto inline-flex h-10 items-center gap-2 rounded-2xl border px-3 text-sm font-medium shadow-float backdrop-blur ${
          layer.visible ? "border-[#1e2235] bg-[#151827]/95 text-[#fde68a]" : "border-line bg-paper/95 text-ink"
        }`}
      >
        <Moon className="size-4" aria-hidden="true" />
        <span>Night view</span>
        {layer.status === "loading" && <Spinner className="size-3.5" />}
        {problem && <CircleAlert className="size-3.5 text-danger" aria-hidden="true" />}
      </button>
      {problem && layer.message && (
        <p className="pointer-events-auto max-w-64 rounded-xl border border-line bg-paper/95 px-3 py-2 text-xs text-ink-soft shadow-float">
          {layer.message}
        </p>
      )}
      {layer.visible && (
        <div className="pointer-events-auto w-56 rounded-xl border border-[#1e2235] bg-[#151827]/95 px-3 py-2 text-[11px] leading-snug text-[#c7c9d6] shadow-float">
          <div
            className="mb-1.5 h-2 rounded-full"
            style={{ background: "linear-gradient(90deg, #1b1e2e, #ff9628 35%, #ffd84a 70%, #fff6e0)" }}
            aria-hidden="true"
          />
          <div className="flex justify-between text-[10px] text-[#8f93a8]">
            <span>Dark</span>
            <span>Bright</span>
          </div>
          <p className="mt-1">
            Night-time light from NASA Black Marble{year ? ` (${year} average)` : ""}, ~500 m squares. Dark patches have
            little light at night.
          </p>
        </div>
      )}
    </>
  );
}
