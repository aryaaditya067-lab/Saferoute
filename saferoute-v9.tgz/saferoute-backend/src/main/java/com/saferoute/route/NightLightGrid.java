package com.saferoute.route;

import com.saferoute.geo.LatLng;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NASA Black Marble night-time radiance on a ~500 m grid (15 arc-seconds), loaded
 * from data/nightlights.csv. "Dark" means the darkest third of the city's cells.
 */
public final class NightLightGrid {

    /** Cells per degree (15 arc-seconds). */
    static final double CELLS_PER_DEGREE = 240;

    private final Map<Long, Double> cells;
    private final double darkThreshold;
    private final String source;
    private final double brightReference;
    private long minRow = Long.MAX_VALUE, maxRow = Long.MIN_VALUE, minCol = Long.MAX_VALUE, maxCol = Long.MIN_VALUE;
    private Raster raster;

    /** The grid as a north-up raster for drawing; values are NaN where there is no data. */
    public record Raster(double south, double west, double north, double east, int rows, int cols, double[] values) {}

    public NightLightGrid(List<double[]> rows, String source) {
        this.cells = new HashMap<>();
        double[] values = new double[rows.size()];
        int i = 0;
        for (double[] r : rows) {
            cells.put(key(r[0], r[1]), r[2]);
            values[i++] = r[2];
            long row = (long) Math.floor(r[0] * CELLS_PER_DEGREE);
            long col = (long) Math.floor(r[1] * CELLS_PER_DEGREE);
            minRow = Math.min(minRow, row);
            maxRow = Math.max(maxRow, row);
            minCol = Math.min(minCol, col);
            maxCol = Math.max(maxCol, col);
        }
        Arrays.sort(values);
        this.darkThreshold = values.length == 0 ? 0 : values[(int) Math.floor((values.length - 1) / 3.0)];
        this.brightReference = values.length == 0 ? 0 : values[(int) Math.floor((values.length - 1) * 0.98)];
        this.source = source;
    }

    /** 98th-percentile radiance: anything brighter is drawn at full brightness. */
    public double brightReference() {
        return brightReference;
    }

    public synchronized Raster raster() {
        if (raster != null || cells.isEmpty()) return raster;
        int rows = (int) (maxRow - minRow + 1);
        int cols = (int) (maxCol - minCol + 1);
        double[] out = new double[rows * cols];
        Arrays.fill(out, Double.NaN);
        for (Map.Entry<Long, Double> e : cells.entrySet()) {
            long row = Math.floorDiv(e.getKey(), 1_000_000L);
            long col = e.getKey() - row * 1_000_000L;
            // Keys use non-negative longitudes here (Bengaluru); north-up: first row is the northernmost.
            int r = (int) (maxRow - row);
            int c = (int) (col - minCol);
            if (r >= 0 && r < rows && c >= 0 && c < cols) out[r * cols + c] = e.getValue();
        }
        raster = new Raster(minRow / CELLS_PER_DEGREE, minCol / CELLS_PER_DEGREE,
                (maxRow + 1) / CELLS_PER_DEGREE, (maxCol + 1) / CELLS_PER_DEGREE, rows, cols, out);
        return raster;
    }

    private static long key(double lat, double lng) {
        long row = (long) Math.floor(lat * CELLS_PER_DEGREE);
        long col = (long) Math.floor(lng * CELLS_PER_DEGREE);
        return row * 1_000_000L + col;
    }

    public Double radianceAt(LatLng p) {
        return cells.get(key(p.lat(), p.lng()));
    }

    public boolean isEmpty() {
        return cells.isEmpty();
    }

    public int size() {
        return cells.size();
    }

    public double darkThreshold() {
        return darkThreshold;
    }

    public String source() {
        return source;
    }

    /** Share of the samples in the city's darkest third, and share that had data at all. */
    public RouteSafety.NightLight measure(List<LatLng> samples) {
        if (samples.isEmpty()) return RouteSafety.NightLight.unavailable();
        int covered = 0, dark = 0;
        double sum = 0;
        for (LatLng p : samples) {
            Double v = radianceAt(p);
            if (v == null) continue;
            covered++;
            sum += v;
            if (v <= darkThreshold) dark++;
        }
        if (covered == 0) return RouteSafety.NightLight.unavailable();
        return new RouteSafety.NightLight(true,
                SafetyScorer.round(dark / (double) covered, 3),
                SafetyScorer.round(covered / (double) samples.size(), 3),
                SafetyScorer.round(sum / covered, 2));
    }
}
