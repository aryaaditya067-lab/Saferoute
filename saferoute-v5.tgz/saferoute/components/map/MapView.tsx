"use client";

import L from "leaflet";
import { useEffect, useRef } from "react";
import { config } from "@/lib/config";
import { formatCoordinates, normalizeCoordinates } from "@/lib/geo";
import { readViewport, writeViewport } from "@/lib/viewport";
import { isBackendConfigured } from "@/services/api";
import { categoryEmoji } from "@/services/community";
import type { CommunitySpot, Coordinates, GeoPosition, Incident, Location, MapBounds, MapInsets, PickTarget, Route } from "@/types";
import { communityIcon, destinationIcon, incidentIcon, LOCATE_SVG, pickupIcon, userIcon } from "./markers";

export type MapFocus =
  | { id: number; type: "point"; point: Coordinates; zoom?: number }
  | { id: number; type: "routes" };

export type PinKind = "pickup" | "destination";

export interface MapViewProps {
  pickup: Location | null;
  destination: Location | null;
  userPosition: GeoPosition | null;
  routes: Route[] | null;
  selectedRouteId: string | null;
  pickTarget: PickTarget | null;
  focus: MapFocus | null;
  insets: MapInsets;
  locating: boolean;
  /** Reported crimes to draw as red areas with a 💬 marker. */
  incidents: Incident[];
  /** Community-reported spots. */
  communitySpots: CommunitySpot[];
  communityConfirmThreshold: number;
  /** Present when community reporting is available. */
  onReportAt?: (point: Coordinates) => void;
  onSelectRoute: (id: string) => void;
  onPick: (target: PickTarget, point: Coordinates) => void;
  onDropPin: (kind: PinKind, point: Coordinates) => void;
  onLocate: () => void;
  onViewChange: (view: { center: Coordinates; bounds: MapBounds; zoom: number }) => void;
}

const WORLD_VIEW = { center: [20, 0] as L.LatLngTuple, zoom: 2 };
const ROUTE_COLOR = "#E87524";
const ALT_ROUTE_COLOR = "#9A9385";

function toLatLng(c: Coordinates): L.LatLngExpression {
  return [c.lat, c.lng];
}

/** Builds popup content with textContent only (place names come from external APIs). */
function locationPopup(title: string, location: Location): HTMLElement {
  const root = document.createElement("div");
  const label = document.createElement("div");
  label.style.cssText = "font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#8a857b";
  label.textContent = title;
  const name = document.createElement("div");
  name.style.cssText = "font-weight:600;margin-top:2px";
  name.textContent = location.name;
  root.append(label, name);
  const detail = location.address ?? formatCoordinates(location);
  if (detail) {
    const address = document.createElement("div");
    address.style.cssText = "color:#57534c;margin-top:2px";
    address.textContent = detail;
    root.append(address);
  }
  return root;
}

function fitRoutes(map: L.Map, routes: Route[] | null, insets: MapInsets) {
  if (!routes?.length) return;
  const bounds = L.latLngBounds([]);
  for (const route of routes) for (const p of route.geometry) bounds.extend([p.lat, p.lng]);
  if (!bounds.isValid()) return;
  map.fitBounds(bounds, {
    paddingTopLeft: [insets.left + 40, insets.top + 40],
    paddingBottomRight: [insets.right + 40, insets.bottom + 40],
    maxZoom: 17,
    animate: true,
  });
}

function formatDay(isoDate: string): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  if (!y || !m || !d) return isoDate;
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  });
}

/** Popup for a reported crime. Text only via textContent; links are https/http only. */
function incidentPopup(incident: Incident): HTMLElement {
  const root = document.createElement("div");
  root.className = "sr-incident-popup";
  const kind = document.createElement("div");
  kind.className = "sr-incident-kind";
  kind.textContent = `${incident.crimeLabel} · ${incident.locality}`;
  const when = document.createElement("div");
  when.className = "sr-incident-meta";
  when.textContent = `Reported for ${formatDay(incident.occurredOn)}`;
  const headline = document.createElement("div");
  headline.className = "sr-incident-headline";
  headline.textContent = incident.headline;
  const quote = document.createElement("blockquote");
  quote.className = "sr-incident-quote";
  quote.textContent = `“${incident.evidenceQuote}”`;
  root.append(kind, when, headline, quote);
  const sources = document.createElement("div");
  sources.className = "sr-incident-sources";
  for (const source of incident.sources) {
    let href: URL;
    try {
      href = new URL(source.url);
    } catch {
      continue;
    }
    if (href.protocol !== "https:" && href.protocol !== "http:") continue;
    const a = document.createElement("a");
    a.href = href.toString();
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = `${source.site || href.hostname} ↗`;
    sources.append(a);
  }
  const note = document.createElement("div");
  note.className = "sr-incident-note";
  note.textContent = "News report · not official police data";
  root.append(sources, note);
  return root;
}

function communityPopup(spot: CommunitySpot, threshold: string): HTMLElement {
  const root = document.createElement("div");
  root.className = "sr-incident-popup";
  const kind = document.createElement("div");
  kind.className = "sr-incident-kind";
  kind.style.color = "#6d28d9";
  kind.textContent = `${categoryEmoji(spot.category)} ${spot.categoryLabel}`;
  const meta = document.createElement("div");
  meta.className = "sr-incident-meta";
  const when = new Date(spot.latestAt);
  meta.textContent = `Reported by ${spot.reporters} ${spot.reporters === 1 ? "person" : "people"} · latest ${
    Number.isNaN(when.getTime()) ? spot.latestAt : when.toLocaleDateString(undefined, { day: "numeric", month: "short" })
  }`;
  root.append(kind, meta);
  for (const n of spot.notes) {
    const q = document.createElement("blockquote");
    q.className = "sr-incident-quote";
    q.textContent = `“${n}”`;
    root.append(q);
  }
  const note = document.createElement("div");
  note.className = "sr-incident-note";
  note.textContent = spot.confirmed
    ? "Community report · confirmed by several people · not verified"
    : `Community report · affects routes after ${threshold} people report it`;
  root.append(note);
  return root;
}

class LocateControl extends L.Control {
  private readonly onClick: () => void;
  button: HTMLButtonElement | null = null;

  constructor(onClick: () => void, options?: L.ControlOptions) {
    super(options);
    this.onClick = onClick;
  }

  onAdd(): HTMLElement {
    const container = L.DomUtil.create("div", "leaflet-bar saferoute-locate");
    const button = L.DomUtil.create("button", "", container);
    button.type = "button";
    button.title = "Show my location";
    button.setAttribute("aria-label", "Show my location");
    button.innerHTML = LOCATE_SVG;
    L.DomEvent.disableClickPropagation(container);
    L.DomEvent.on(button, "click", (event) => {
      L.DomEvent.preventDefault(event);
      this.onClick();
    });
    this.button = button;
    return container;
  }
}

export default function MapView(props: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);
  const incidentLayerRef = useRef<L.LayerGroup | null>(null);
  const communityLayerRef = useRef<L.LayerGroup | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const destinationMarkerRef = useRef<L.Marker | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);
  const locateControlRef = useRef<LocateControl | null>(null);

  // Latest props for Leaflet event handlers, so handlers are bound once.
  const latest = useRef(props);
  useEffect(() => {
    latest.current = props;
  });

  // ---- Create the map exactly once ----------------------------------------
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const stored = readViewport();
    const map = L.map(container, {
      center: stored ? [stored.lat, stored.lng] : WORLD_VIEW.center,
      zoom: stored ? stored.zoom : WORLD_VIEW.zoom,
      minZoom: 2,
      maxZoom: 19,
      zoomControl: false,
      worldCopyJump: true,
    });

    map.attributionControl.setPrefix('<a href="https://leafletjs.com" target="_blank" rel="noreferrer">Leaflet</a>');
    L.tileLayer(config.tileUrl, {
      maxZoom: 19,
      attribution: config.tileAttribution,
      crossOrigin: true,
    }).addTo(map);
    if (!isBackendConfigured()) {
      map.attributionControl.addAttribution(
        'Search <a href="https://photon.komoot.io" target="_blank" rel="noreferrer">Photon</a> · Routing <a href="https://routing.openstreetmap.de/about.html" target="_blank" rel="noreferrer">FOSSGIS OSRM</a>',
      );
    }

    // Bottom-right stack: locate button below the zoom buttons.
    const locate = new LocateControl(() => latest.current.onLocate(), { position: "bottomright" });
    locate.addTo(map);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    locateControlRef.current = locate;

    // Reported-crime areas sit under the routes; their 💬 markers sit above them.
    map.createPane("incidentAreas").style.zIndex = "350";
    map.createPane("incidentMarkers").style.zIndex = "620";
    incidentLayerRef.current = L.layerGroup().addTo(map);
    communityLayerRef.current = L.layerGroup().addTo(map);
    routeLayerRef.current = L.layerGroup().addTo(map);

    map.on("click", (event: L.LeafletMouseEvent) => {
      const target = latest.current.pickTarget;
      if (target) latest.current.onPick(target, normalizeCoordinates(event.latlng));
    });

    // Right-click (desktop) or long-press (touch) drops a pin with actions.
    map.on("contextmenu", (event: L.LeafletMouseEvent) => {
      const point = normalizeCoordinates(event.latlng);
      const root = document.createElement("div");
      const title = document.createElement("div");
      title.style.cssText = "font-weight:600";
      title.textContent = "Dropped pin";
      const coords = document.createElement("div");
      coords.style.cssText = "color:#8a857b;font-size:12px;margin-top:2px;font-variant-numeric:tabular-nums";
      coords.textContent = formatCoordinates(point);
      const actions = document.createElement("div");
      actions.className = "sr-popup-actions";
      const makeButton = (kind: PinKind, text: string, color: string) => {
        const button = document.createElement("button");
        button.type = "button";
        const swatch = document.createElement("span");
        swatch.className = "sr-swatch";
        swatch.style.background = color;
        button.append(swatch, document.createTextNode(text));
        button.addEventListener("click", () => {
          map.closePopup();
          latest.current.onDropPin(kind, point);
        });
        return button;
      };
      actions.append(
        makeButton("pickup", "Set as pickup", "#242321"),
        makeButton("destination", "Set as destination", ROUTE_COLOR),
      );
      if (latest.current.onReportAt) {
        const report = document.createElement("button");
        report.type = "button";
        const swatch = document.createElement("span");
        swatch.className = "sr-swatch";
        swatch.style.background = "#7c3aed";
        report.append(swatch, document.createTextNode("Report a safety issue here"));
        report.addEventListener("click", () => {
          map.closePopup();
          latest.current.onReportAt?.(point);
        });
        actions.append(report);
      }
      root.append(title, coords, actions);
      L.popup({ closeButton: true, autoPanPadding: [24, 24] }).setLatLng(event.latlng).setContent(root).openOn(map);
    });

    const reportView = () => {
      const center = normalizeCoordinates(map.getCenter());
      const b = map.getBounds();
      latest.current.onViewChange({
        center,
        zoom: map.getZoom(),
        bounds: {
          south: Math.max(-90, b.getSouth()),
          west: Math.max(-180, b.getWest()),
          north: Math.min(90, b.getNorth()),
          east: Math.min(180, b.getEast()),
        },
      });
    };

    map.on("moveend", () => {
      const center = normalizeCoordinates(map.getCenter());
      writeViewport({ lat: center.lat, lng: center.lng, zoom: map.getZoom() });
      reportView();
    });

    mapRef.current = map;
    reportView();

    return () => {
      map.off();
      map.remove();
      mapRef.current = null;
      routeLayerRef.current = null;
      incidentLayerRef.current = null;
      communityLayerRef.current = null;
      pickupMarkerRef.current = null;
      destinationMarkerRef.current = null;
      userMarkerRef.current = null;
      accuracyCircleRef.current = null;
      locateControlRef.current = null;
    };
  }, []);

  // ---- Pick mode cursor ------------------------------------------------------
  const picking = props.pickTarget !== null;
  useEffect(() => {
    containerRef.current?.classList.toggle("is-picking", picking);
    if (picking) mapRef.current?.closePopup();
  }, [picking]);

  // ---- Bottom inset (keeps controls above the mobile sheet) ----------------
  useEffect(() => {
    containerRef.current?.style.setProperty("--map-inset-bottom", `${Math.round(props.insets.bottom)}px`);
  }, [props.insets.bottom]);

  // ---- Locate button state ---------------------------------------------------
  const hasUserPosition = props.userPosition !== null;
  useEffect(() => {
    const button = locateControlRef.current?.button;
    if (!button) return;
    button.setAttribute("aria-busy", String(props.locating));
    button.setAttribute("data-active", String(hasUserPosition));
  }, [props.locating, hasUserPosition]);

  // ---- Markers ---------------------------------------------------------------
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const location = props.pickup;
    if (!location) {
      pickupMarkerRef.current?.remove();
      pickupMarkerRef.current = null;
      return;
    }
    let marker = pickupMarkerRef.current;
    if (!marker) {
      marker = L.marker(toLatLng(location), {
        icon: pickupIcon,
        draggable: true,
        title: "Pickup — drag to adjust",
        alt: "Pickup",
        zIndexOffset: 400,
        autoPan: true,
      }).addTo(map);
      const m = marker;
      m.on("dragend", () => latest.current.onDropPin("pickup", normalizeCoordinates(m.getLatLng())));
      pickupMarkerRef.current = m;
    } else {
      marker.setLatLng(toLatLng(location));
    }
    marker.bindPopup(locationPopup("Pickup", location));
  }, [props.pickup]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const location = props.destination;
    if (!location) {
      destinationMarkerRef.current?.remove();
      destinationMarkerRef.current = null;
      return;
    }
    let marker = destinationMarkerRef.current;
    if (!marker) {
      marker = L.marker(toLatLng(location), {
        icon: destinationIcon,
        draggable: true,
        title: "Destination — drag to adjust",
        alt: "Destination",
        zIndexOffset: 500,
        autoPan: true,
      }).addTo(map);
      const m = marker;
      m.on("dragend", () => latest.current.onDropPin("destination", normalizeCoordinates(m.getLatLng())));
      destinationMarkerRef.current = m;
    } else {
      marker.setLatLng(toLatLng(location));
    }
    marker.bindPopup(locationPopup("Destination", location));
  }, [props.destination]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const position = props.userPosition;
    if (!position) {
      userMarkerRef.current?.remove();
      accuracyCircleRef.current?.remove();
      userMarkerRef.current = null;
      accuracyCircleRef.current = null;
      return;
    }
    const latLng = toLatLng(position);
    if (!accuracyCircleRef.current) {
      accuracyCircleRef.current = L.circle(latLng, {
        radius: position.accuracyMeters,
        color: "#2f6fed",
        weight: 1,
        opacity: 0.4,
        fillColor: "#2f6fed",
        fillOpacity: 0.1,
        interactive: false,
      }).addTo(map);
    } else {
      accuracyCircleRef.current.setLatLng(latLng).setRadius(position.accuracyMeters);
    }
    if (!userMarkerRef.current) {
      userMarkerRef.current = L.marker(latLng, {
        icon: userIcon,
        interactive: false,
        keyboard: false,
        zIndexOffset: 300,
      }).addTo(map);
    } else {
      userMarkerRef.current.setLatLng(latLng);
    }
  }, [props.userPosition]);

  // ---- Reported crimes -------------------------------------------------------
  useEffect(() => {
    const layer = incidentLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    for (const incident of props.incidents) {
      const center: L.LatLngExpression = [incident.lat, incident.lng];
      layer.addLayer(
        L.circle(center, {
          pane: "incidentAreas",
          radius: incident.radiusMeters,
          stroke: false,
          fillColor: "#DC2626",
          fillOpacity: incident.category === "violent" ? 0.2 : 0.13,
          interactive: false,
        }),
      );
      const marker = L.marker(center, {
        pane: "incidentMarkers",
        icon: incidentIcon,
        title: `${incident.crimeLabel} · ${incident.locality}`,
        alt: `${incident.crimeLabel} reported in ${incident.locality}`,
        riseOnHover: true,
      });
      marker.bindPopup(() => incidentPopup(incident), { maxWidth: 300, className: "sr-incident-popup-wrap" });
      layer.addLayer(marker);
    }
  }, [props.incidents]);

  // ---- Community spots ---------------------------------------------------------
  const threshold = props.communityConfirmThreshold;
  useEffect(() => {
    const layer = communityLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    for (const spot of props.communitySpots) {
      const marker = L.marker([spot.lat, spot.lng], {
        pane: "incidentMarkers",
        icon: communityIcon(categoryEmoji(spot.category), spot.confirmed),
        title: `${spot.categoryLabel} · ${spot.reporters} report${spot.reporters === 1 ? "" : "s"}`,
        alt: `Community report: ${spot.categoryLabel}`,
        riseOnHover: true,
      });
      marker.bindPopup(() => communityPopup(spot, String(threshold)), { maxWidth: 280 });
      layer.addLayer(marker);
    }
  }, [props.communitySpots, threshold]);

  // ---- Routes ----------------------------------------------------------------
  useEffect(() => {
    const layer = routeLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    const routes = props.routes;
    if (!routes?.length) return;

    const selected = routes.find((r) => r.id === props.selectedRouteId) ?? routes[0]!;
    for (const route of routes) {
      if (route.id === selected.id) continue;
      const line = L.polyline(route.geometry.map(toLatLng), {
        color: ALT_ROUTE_COLOR,
        weight: 6,
        opacity: 0.85,
        lineCap: "round",
        lineJoin: "round",
      });
      line.on("click", (event) => {
        L.DomEvent.stopPropagation(event);
        latest.current.onSelectRoute(route.id);
      });
      line.bindTooltip("Show this route", { sticky: true, direction: "top", opacity: 0.9 });
      layer.addLayer(line);
    }
    const coords = selected.geometry.map(toLatLng);
    layer.addLayer(L.polyline(coords, { color: "#FFFDF8", weight: 11, opacity: 1, interactive: false, lineCap: "round", lineJoin: "round" }));
    layer.addLayer(L.polyline(coords, { color: ROUTE_COLOR, weight: 6, opacity: 1, interactive: false, lineCap: "round", lineJoin: "round" }));
  }, [props.routes, props.selectedRouteId]);

  // ---- Camera ----------------------------------------------------------------
  const lastRoutesFitAt = useRef(0);

  const focusId = props.focus?.id;
  useEffect(() => {
    const map = mapRef.current;
    const focus = latest.current.focus;
    if (!map || !focus) return;
    const { top, right, bottom, left } = latest.current.insets;

    if (focus.type === "point") {
      lastRoutesFitAt.current = 0;
      const zoom = focus.zoom ?? Math.max(map.getZoom(), 15);
      const projected = map.project(toLatLng(focus.point), zoom);
      const offset = L.point((left - right) / 2, (top - bottom) / 2);
      map.setView(map.unproject(projected.subtract(offset), zoom), zoom, { animate: true });
      return;
    }

    lastRoutesFitAt.current = Date.now();
    fitRoutes(map, latest.current.routes, latest.current.insets);
  }, [focusId]);

  // If the panel resizes right after fitting routes (e.g. the mobile sheet
  // collapses to show the map), fit again so the route stays fully visible.
  const { top, right, bottom, left } = props.insets;
  useEffect(() => {
    const map = mapRef.current;
    if (!map || Date.now() - lastRoutesFitAt.current > 1500) return;
    const refit = () => fitRoutes(map, latest.current.routes, { top, right, bottom, left });
    // Leaflet ignores a new view while a zoom animation runs, so wait for it to finish.
    if ((map as unknown as { _animatingZoom?: boolean })._animatingZoom) map.once("zoomend", refit);
    else refit();
  }, [top, right, bottom, left]);

  return (
    <div
      ref={containerRef}
      className="saferoute-map absolute inset-0 h-full w-full"
      role="application"
      aria-label="Map. Right-click or long-press to drop a pin."
    />
  );
}
