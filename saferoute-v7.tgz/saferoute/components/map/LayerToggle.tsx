"use client";

import { CircleAlert, Eye, EyeOff } from "lucide-react";
import { Spinner } from "@/components/ui/Spinner";

interface LayerToggleProps {
  label: string;
  shortLabel: string;
  dotClass: string;
  status: "idle" | "loading" | "ready" | "error" | "zoomed-out";
  count: number;
  emptyText?: string | null;
  title: string;
  error: string | null;
  visible: boolean;
  onToggle: () => void;
  onRetry: () => void;
}

/** Map chip that shows/hides a data layer and how many items are in view. */
export function LayerToggle(p: LayerToggleProps) {
  let detail: React.ReactNode;
  if (p.status === "loading") detail = <Spinner className="size-3.5 text-ink-muted" />;
  else if (p.status === "zoomed-out") detail = <span className="text-ink-muted">Zoom in</span>;
  else if (p.status === "error") detail = <CircleAlert className="size-3.5 text-danger" aria-hidden="true" />;
  else if (p.status === "ready" && p.emptyText) detail = <span className="text-ink-muted">{p.emptyText}</span>;
  else if (p.status === "ready") detail = <span className="tabular-nums">{p.count} in view</span>;

  return (
    <button
      type="button"
      onClick={p.status === "error" ? p.onRetry : p.onToggle}
      aria-pressed={p.visible}
      title={p.status === "error" ? `${p.error} Click to retry.` : p.title}
      className={`pointer-events-auto inline-flex h-10 items-center gap-2 rounded-2xl border border-line bg-paper/95 px-3 text-sm font-medium shadow-float backdrop-blur ${
        p.visible ? "text-ink" : "text-ink-muted"
      }`}
    >
      <span className={`size-2.5 rounded-full ${p.visible ? p.dotClass : "bg-line-strong"}`} aria-hidden="true" />
      <span className="hidden sm:inline">{p.label}</span>
      <span className="sm:hidden">{p.shortLabel}</span>
      {detail && <span className="text-xs font-normal">{detail}</span>}
      {p.visible ? <Eye className="size-4 text-ink-muted" aria-hidden="true" /> : <EyeOff className="size-4 text-ink-muted" aria-hidden="true" />}
    </button>
  );
}
