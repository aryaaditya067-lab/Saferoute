package com.saferoute.route;

import com.saferoute.geo.LatLng;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NASA Black Marble night-time radiance on a ~500 m grid (15 arc-seconds), loaded
 * from data/nightlights.csv. "Dark" means the darkest third of the city's cells.
 */
public final class NightLightGrid {

    /** Cells per degree (15 arc-seconds). */
    static final double CELLS_PER_DEGREE = 240;

    private final Map<Long, Double> cells;
    private final double darkThreshold;
    private final String source;

    public NightLightGrid(List<double[]> rows, String source) {
        this.cells = new HashMap<>();
        double[] values = new double[rows.size()];
        int i = 0;
        for (double[] r : rows) {
            cells.put(key(r[0], r[1]), r[2]);
            values[i++] = r[2];
        }
        Arrays.sort(values);
        this.darkThreshold = values.length == 0 ? 0 : values[(int) Math.floor((values.length - 1) / 3.0)];
        this.source = source;
    }

    private static long key(double lat, double lng) {
        long row = (long) Math.floor(lat * CELLS_PER_DEGREE);
        long col = (long) Math.floor(lng * CELLS_PER_DEGREE);
        return row * 1_000_000L + col;
    }

    public Double radianceAt(LatLng p) {
        return cells.get(key(p.lat(), p.lng()));
    }

    public boolean isEmpty() {
        return cells.isEmpty();
    }

    public int size() {
        return cells.size();
    }

    public double darkThreshold() {
        return darkThreshold;
    }

    public String source() {
        return source;
    }

    /** Share of the samples in the city's darkest third, and share that had data at all. */
    public RouteSafety.NightLight measure(List<LatLng> samples) {
        if (samples.isEmpty()) return RouteSafety.NightLight.unavailable();
        int covered = 0, dark = 0;
        double sum = 0;
        for (LatLng p : samples) {
            Double v = radianceAt(p);
            if (v == null) continue;
            covered++;
            sum += v;
            if (v <= darkThreshold) dark++;
        }
        if (covered == 0) return RouteSafety.NightLight.unavailable();
        return new RouteSafety.NightLight(true,
                SafetyScorer.round(dark / (double) covered, 3),
                SafetyScorer.round(covered / (double) samples.size(), 3),
                SafetyScorer.round(sum / covered, 2));
    }
}
