package com.saferoute.route;

import com.saferoute.geo.BBox;
import com.saferoute.geo.LatLng;
import java.util.List;

/** OpenStreetMap features along a set of candidate routes. */
public record OsmContext(List<Road> roads, List<Poi> police, List<Poi> hospitals, List<Poi> activity) {

    /**
     * A road near the routes. {@code lit} is null when OpenStreetMap has no lit tag.
     * {@code major} = trunk / primary / secondary / tertiary (and their links).
     */
    public record Road(List<LatLng> geometry, String highway, boolean major, Boolean lit, BBox bounds) {}

    public record Poi(long osmId, String name, LatLng location) {}
}
