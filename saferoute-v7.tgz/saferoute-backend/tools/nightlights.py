"""
Downloads NASA Black Marble yearly night-time lights (VNP46A4, ~500 m) for the
Bengaluru area and writes data/nightlights.csv for the SafeRoute backend.

Usage (Windows PowerShell, from the saferoute-backend folder):
    py -m pip install blackmarblepy geopandas
    $env:BLACKMARBLE_TOKEN = "<NASA Earthdata token>"
    py tools\nightlights.py            # latest available year
    py tools\nightlights.py 2024       # a specific year

Token: https://urs.earthdata.nasa.gov/profile -> "Generate Token"
(fill in "Affiliation" on your profile first, or the token is rejected).
Uses the World Bank's blackmarblepy: https://worldbank.github.io/blackmarblepy/
"""

import datetime as dt
import os
import sys
from pathlib import Path

# Same box as saferoute.city.bbox in application.yml (south, west, north, east).
SOUTH, WEST, NORTH, EAST = 12.73, 77.37, 13.23, 77.88
VARIABLE = "NearNadir_Composite_Snow_Free"
OUT = Path(__file__).resolve().parent.parent / "data" / "nightlights.csv"


def main() -> None:
    if not os.environ.get("BLACKMARBLE_TOKEN"):
        sys.exit("Set BLACKMARBLE_TOKEN to your NASA Earthdata token first.")

    import geopandas as gpd
    from shapely.geometry import box
    from blackmarble import BlackMarble, Product

    gdf = gpd.GeoDataFrame(geometry=[box(WEST, SOUTH, EAST, NORTH)], crs="EPSG:4326")
    bm = BlackMarble()

    first = int(sys.argv[1]) if len(sys.argv) > 1 else dt.date.today().year - 1
    dataset, year = None, None
    for y in (first, first - 1, first - 2):
        try:
            print(f"Downloading NASA Black Marble {y} (VNP46A4)...")
            dataset = bm.raster(gdf, product_id=Product.VNP46A4, date_range=dt.date(y, 1, 1), variable=VARIABLE)
            year = y
            break
        except Exception as error:  # year not published yet, network, ...
            print(f"  {y} not available: {error}")
    if dataset is None:
        sys.exit("Could not download any year. Check the token and your internet connection.")

    layer = dataset[VARIABLE] if VARIABLE in dataset else dataset[list(dataset.data_vars)[0]]
    if "time" in layer.dims:
        layer = layer.isel(time=0)
    frame = layer.to_dataframe(name="radiance").reset_index()
    frame = frame[["y", "x", "radiance"]].dropna()
    frame = frame[(frame.y >= SOUTH) & (frame.y <= NORTH) & (frame.x >= WEST) & (frame.x <= EAST)]

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="") as f:
        f.write(f"# source=NASA Black Marble VNP46A4 {VARIABLE} year={year} unit=nW/cm2/sr\n")
        f.write("lat,lng,radiance\n")
        for row in frame.itertuples(index=False):
            f.write(f"{row.y:.6f},{row.x:.6f},{row.radiance:.3f}\n")
    print(f"Wrote {len(frame)} cells for {year} to {OUT}")
    print("Done. The backend picks it up on the next route search (no restart needed).")


if __name__ == "__main__":
    main()
