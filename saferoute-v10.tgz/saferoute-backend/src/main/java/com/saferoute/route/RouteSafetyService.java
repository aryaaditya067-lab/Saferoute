package com.saferoute.route;

import com.saferoute.common.ApiException;
import com.saferoute.community.CommunityService;
import com.saferoute.config.SafeRouteProperties;
import com.saferoute.geo.BBox;
import com.saferoute.geo.Geo;
import com.saferoute.geo.LatLng;
import com.saferoute.incident.Incident;
import com.saferoute.incident.IncidentController;
import com.saferoute.incident.IncidentStore;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Builds candidate routes, measures them and labels Fastest / Balanced / Safest.
 *
 * <p>Candidates are the routing provider's own alternatives plus, when the
 * fastest route crosses a reported-crime area, up to two detours that pass on
 * either side of that area.
 */
@Service
public class RouteSafetyService {

    private static final Logger log = LoggerFactory.getLogger(RouteSafetyService.class);
    private static final double MIN_SEPARATION_METERS = 15;
    private static final double MAX_OSM_AREA_KM2 = 1500;
    private static final int MAX_ROUTES = 3;

    private final OsrmClient osrm;
    private final OverpassClient overpass;
    private final IncidentStore store;
    private final CommunityService community;
    private final NightLightService nightLights;
    private final SafeRouteProperties properties;
    private final SafetyScorer scorer;
    private final BBox cityBox;
    private final Clock clock;

    public RouteSafetyService(OsrmClient osrm, OverpassClient overpass, IncidentStore store, CommunityService community,
                              NightLightService nightLights, SafeRouteProperties properties, Clock clock) {
        this.community = community;
        this.nightLights = nightLights;
        this.osrm = osrm;
        this.overpass = overpass;
        this.store = store;
        this.properties = properties;
        this.scorer = new SafetyScorer(properties.safety());
        SafeRouteProperties.BBoxConfig b = properties.city().bbox();
        this.cityBox = new BBox(b.south(), b.west(), b.north(), b.east());
        this.clock = clock;
    }

    public RouteDtos.RouteResponse plan(RouteDtos.RouteRequest request) {
        LatLng pickup = toLatLng(request.pickup(), "pickup");
        LatLng destination = toLatLng(request.destination(), "destination");
        if (Geo.distanceMeters(pickup, destination) < MIN_SEPARATION_METERS) {
            throw new IllegalArgumentException("Pickup and destination are the same place.");
        }
        TravelMode mode = TravelMode.parse(request.mode());
        LocalDate today = LocalDate.now(clock);
        SafeRouteProperties.Safety safety = properties.safety();

        List<RouteCandidate> candidates = new ArrayList<>(osrm.route(List.of(pickup, destination), mode, true));
        RouteCandidate fastest = candidates.stream().min(Comparator.comparingDouble(RouteCandidate::durationSeconds)).orElseThrow();

        // Crime data counts as available only if an ingest has succeeded and the trip is inside the covered city.
        var lastIngest = store.lastSuccessfulRun();
        boolean crimeAvailable = lastIngest.isPresent() && cityBox.contains(pickup) && cityBox.contains(destination);
        List<Incident> incidents = crimeAvailable ? store.findSince(today.minusDays(safety.incidentWindowDays())) : null;

        double maxDuration = fastest.durationSeconds() * safety.maxDetourFactor();
        if (incidents != null && !incidents.isEmpty()) {
            Incident worst = SafetyScorer.worstIncident(fastest.geometry(), incidents, safety, today);
            if (worst != null) candidates.addAll(detoursAround(worst, fastest, pickup, destination, mode));
        }
        candidates = distinct(candidates, maxDuration);

        // Make sure there are real alternatives to compare: route via points on either
        // side of the fastest route until three distinct candidates exist.
        for (double share : new double[] {0.15, 0.3, 0.45}) {
            if (candidates.size() >= MAX_ROUTES) break;
            List<RouteCandidate> more = new ArrayList<>(candidates);
            more.addAll(sideRoutes(fastest, pickup, destination, mode, share));
            candidates = distinct(more, maxDuration);
        }

        OsmContext osm = null;
        List<LatLng> all = candidates.stream().flatMap(c -> c.geometry().stream()).toList();
        BBox area = BBox.around(all).expand(safety.serviceRadiusMeters());
        if (area.areaSquareKm() <= MAX_OSM_AREA_KM2) {
            try {
                osm = overpass.fetch(candidates.stream().map(RouteCandidate::geometry).toList(), area);
            } catch (ApiException e) {
                log.warn("OpenStreetMap context unavailable: {}", e.getMessage());
            }
        }

        List<CommunityService.Spot> spots = null;
        if (cityBox.contains(pickup) && cityBox.contains(destination)) {
            try {
                spots = community.confirmedSpots();
            } catch (RuntimeException e) {
                log.warn("Community reports unavailable: {}", e.getMessage());
            }
        }
        SafetyScorer.Outcome outcome = scorer.score(candidates, incidents, spots, osm, nightLights.grid(), today);
        List<SafetyScorer.Scored> chosen = outcome.routes().stream()
                .sorted(Comparator.comparing((SafetyScorer.Scored s) -> s.labels().isEmpty())
                        .thenComparingDouble(s -> s.route().durationSeconds()))
                .limit(MAX_ROUTES)
                .toList();

        LocalDateTime localNow = LocalDateTime.now(clock.withZone(cityZone()));
        List<RouteDtos.RouteDto> routes = new ArrayList<>();
        for (int i = 0; i < chosen.size(); i++) {
            SafetyScorer.Scored s = chosen.get(i);
            RouteSafety facts = osm == null ? s.safety()
                    : s.safety().withOpenNow(WalkInfo.openNow(s.route().geometry(), osm.activity(), localNow));
            routes.add(new RouteDtos.RouteDto(
                    "route-" + i, i,
                    s.route().geometry().stream().map(p -> new RouteDtos.Coordinates(p.lat(), p.lng())).toList(),
                    Math.round(s.route().distanceMeters() * 10) / 10.0,
                    Math.round(s.route().durationSeconds() * 10) / 10.0,
                    s.route().summary(),
                    s.labels().stream().map(l -> l.name().toLowerCase(Locale.ROOT)).toList(),
                    facts));
        }

        Map<String, Double> weights = new LinkedHashMap<>();
        for (SafetyScorer.Factor f : outcome.factorsUsed()) {
            weights.put(factorId(f), SafetyScorer.weight(safety.weights(), f));
        }
        String crimeNote = crimeAvailable
                ? IncidentController.SOURCE_NOTE
                : (lastIngest.isEmpty()
                        ? "No crime reports have been collected yet."
                        : "Crime reports are only collected for " + properties.city().name() + ".");

        return new RouteDtos.RouteResponse(
                routes,
                mode.id(),
                new RouteDtos.Coordinates(pickup.lat(), pickup.lng()),
                new RouteDtos.Coordinates(destination.lat(), destination.lng()),
                "OSRM · FOSSGIS (OpenStreetMap data)",
                clock.instant().toString(),
                new RouteDtos.SafetyMethod(
                        crimeAvailable, crimeNote, osm != null,
                        outcome.factorsUsed().stream().map(RouteSafetyService::factorId).toList(),
                        weights,
                        safety.incidentWindowDays(),
                        safety.serviceRadiusMeters(),
                        lastIngest.map(r -> r.finishedAt() == null ? null : r.finishedAt().toString()).orElse(null)),
                mode == TravelMode.WALKING
                        ? WalkInfo.transit(pickup, destination, osm == null ? null : osm.stations(), localNow, properties.transit())
                        : null);
    }

    private ZoneId cityZone() {
        SafeRouteProperties.Transit t = properties.transit();
        try {
            return t == null || t.timeZone() == null || t.timeZone().isBlank() ? ZoneId.of("Asia/Kolkata") : ZoneId.of(t.timeZone());
        } catch (RuntimeException e) {
            return ZoneId.of("Asia/Kolkata");
        }
    }

    /** JSON id of a factor: "crime", "nightLight", "darkness", "mainRoads", "activity", "police", "hospital". */
    static String factorId(SafetyScorer.Factor f) {
        return switch (f) {
            case MAIN_ROADS -> "mainRoads";
            case NIGHT_LIGHT -> "nightLight";
            default -> f.name().toLowerCase(Locale.ROOT);
        };
    }

    /** Routes through points left and right of the fastest route's midpoint. */
    private List<RouteCandidate> sideRoutes(RouteCandidate fastest, LatLng pickup, LatLng destination, TravelMode mode, double share) {
        List<LatLng> g = fastest.geometry();
        int mid = g.size() / 2;
        LatLng center = g.get(mid);
        double heading = Geo.bearing(pickup, destination);
        double offset = Math.max(500, Math.min(5000, Geo.distanceMeters(pickup, destination) * share));
        List<RouteCandidate> out = new ArrayList<>();
        for (double side : new double[] {90, -90}) {
            LatLng via = Geo.offset(center, heading + side, offset);
            try {
                out.addAll(osrm.route(List.of(pickup, via, destination), mode, false));
            } catch (ApiException e) {
                log.debug("Alternative via {} not routable: {}", via, e.getMessage());
            }
        }
        return out;
    }

    private List<RouteCandidate> detoursAround(Incident incident, RouteCandidate route, LatLng pickup, LatLng destination, TravelMode mode) {
        List<LatLng> g = route.geometry();
        int i = Geo.nearestVertex(incident.center(), g);
        LatLng before = g.get(Math.max(0, i - 5));
        LatLng after = g.get(Math.min(g.size() - 1, i + 5));
        double heading = Geo.bearing(before, after);
        int radius = Math.max(properties.safety().minIncidentRadiusMeters(),
                Math.min(properties.safety().maxIncidentRadiusMeters(), incident.radiusMeters()));
        double offset = radius + 400;
        List<RouteCandidate> out = new ArrayList<>();
        for (double side : new double[] {90, -90}) {
            LatLng via = Geo.offset(incident.center(), heading + side, offset);
            try {
                out.addAll(osrm.route(List.of(pickup, via, destination), mode, false));
            } catch (ApiException e) {
                log.debug("Detour via {} not routable: {}", via, e.getMessage());
            }
        }
        return out;
    }

    /** Drops near-duplicates (≥90% shared path) and unreasonable detours; keeps the faster of duplicates. */
    static List<RouteCandidate> distinct(List<RouteCandidate> candidates, double maxDuration) {
        List<RouteCandidate> sorted = candidates.stream()
                .filter(c -> c.durationSeconds() <= maxDuration + 1e-6)
                .sorted(Comparator.comparingDouble(RouteCandidate::durationSeconds))
                .toList();
        List<RouteCandidate> kept = new ArrayList<>();
        for (RouteCandidate c : sorted) {
            List<LatLng> samples = Geo.resample(c.geometry(), 50);
            boolean duplicate = kept.stream().anyMatch(k -> sharedFraction(samples, k.geometry()) >= 0.9
                    && sharedFraction(Geo.resample(k.geometry(), 50), c.geometry()) >= 0.9);
            if (!duplicate) kept.add(c);
        }
        return kept;
    }

    private static double sharedFraction(List<LatLng> samples, List<LatLng> other) {
        if (samples.isEmpty()) return 1;
        long near = samples.stream().filter(p -> Geo.distanceToPolylineMeters(p, other) <= 30).count();
        return near / (double) samples.size();
    }

    private static LatLng toLatLng(RouteDtos.Coordinates c, String name) {
        if (c == null || c.lat() == null || c.lng() == null) {
            throw new IllegalArgumentException("Missing " + name + " coordinates.");
        }
        try {
            return new LatLng(c.lat(), c.lng());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("The " + name + " location isn't valid.");
        }
    }
}
